# 结算层修复材料

database/schema.sql定义只读来源表，database/seed.sql提供脱敏结算记录。rules/settlement_policy.csv是业务规则，rules/report_layout.csv控制四张报告。starter/repair_settlement_access.sql用于填写完成版SQL，tools/run-task.ps1负责调用psql和导出结果。

把完成版放到output/repair_settlement_access.sql，在input_data根目录执行tools/run-task.ps1。连接参数使用PGHOST、PGPORT、PGUSER、PGPASSWORD和PGDATABASE。入口会重建raw与settlement模式，正式运行只连接指定数据库。
