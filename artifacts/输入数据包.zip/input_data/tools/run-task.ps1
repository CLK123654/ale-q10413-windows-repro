param(
  [string]$PsqlPath = $env:PSQL_PATH
)

$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$output = Join-Path $root 'output'
$reports = Join-Path $output 'reports'
$solution = Join-Path $output 'repair_settlement_access.sql'
$policy = Join-Path $root 'rules/settlement_policy.csv'
  $layout = Join-Path $root 'rules/report_layout.csv'

function Remove-DerivedOutput {
  Remove-Item -LiteralPath $reports -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath (Join-Path $output '.driver.sql') -Force -ErrorAction SilentlyContinue
}

function Quote-Psql([string]$Value) {
  return $Value.Replace("'", "''")
}

try {
  foreach ($required in @($solution, $policy, $layout, (Join-Path $root 'database/schema.sql'), (Join-Path $root 'database/seed.sql'))) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) { throw "缺少输入文件：$required" }
  }
  if ([string]::IsNullOrWhiteSpace($PsqlPath)) { $PsqlPath = (Get-Command psql -ErrorAction Stop).Source }
  $layouts = @(Import-Csv -LiteralPath $layout -Encoding utf8)
  if ($layouts.Count -ne 4) { throw '报表布局需要四个文件' }
  foreach ($item in $layouts) {
    if ($item.report_file -notmatch '^[a-z0-9_]+\.csv$' -or $item.source_object -notmatch '^settlement\.[a-z_]+$') { throw '报表布局含非法对象' }
    if ($item.columns -notmatch '^[a-z0-9_|]+$' -or $item.order_by -notmatch '^[a-z0-9_|]+$') { throw '报表布局含非法字段' }
  }
  $policyRows = @(Import-Csv -LiteralPath $policy -Encoding utf8)
  $scalar = @{}
  foreach ($row in $policyRows | Where-Object { $_.policy_kind -eq 'scalar' }) { $scalar[$row.policy_key] = $row.policy_value }
  foreach ($name in @('report_start_utc','report_end_utc','active_tenant_status','posted_status','tenant_setting')) {
    if ([string]::IsNullOrWhiteSpace($scalar[$name])) { throw "结算策略缺少标量：$name" }
  }
  if ([DateTimeOffset]::Parse($scalar.report_start_utc) -ge [DateTimeOffset]::Parse($scalar.report_end_utc)) { throw '结算策略的报表区间无效' }
  if (($policyRows | Where-Object { $_.policy_kind -eq 'reversal_reason' }).Count -ne 4) { throw '结算策略需要四项冲销原因' }
  New-Item -ItemType Directory -Path $output -Force | Out-Null
  Remove-DerivedOutput
  $driver = Join-Path $output '.driver.sql'
  $schema = (Join-Path $root 'database/schema.sql').Replace('\','/')
  $seed = (Join-Path $root 'database/seed.sql').Replace('\','/')
  $solutionSql = $solution.Replace('\','/')
  $policyCsv = $policy.Replace('\','/')
  $driverRows = @(
    '\set ON_ERROR_STOP on',
    "\i '$schema'",
    "\i '$seed'",
    'CREATE TEMP TABLE task_policy(policy_kind text,policy_key text,policy_value text,priority integer);',
    "\copy task_policy FROM '$policyCsv' WITH (FORMAT csv,HEADER true,ENCODING 'UTF8')",
    "\i '$solutionSql'"
  )
  Set-Content -LiteralPath $driver -Value $driverRows -Encoding utf8NoBOM
  & $PsqlPath -X -v ON_ERROR_STOP=1 -f $driver
  if ($LASTEXITCODE -ne 0) { throw "PostgreSQL执行失败，退出码$LASTEXITCODE" }
  New-Item -ItemType Directory -Path $reports -Force | Out-Null
  foreach ($item in $layouts) {
    $columns = ($item.columns -split '\|') -join ','
    $orderBy = ($item.order_by -split '\|') -join ','
    $query = "SELECT $columns FROM $($item.source_object) ORDER BY $orderBy"
    $target = (Join-Path $reports $item.report_file).Replace('\','/')
    & $PsqlPath -X -v ON_ERROR_STOP=1 -c "\copy ($query) TO '$target' WITH (FORMAT csv,HEADER true,ENCODING 'UTF8')"
    if ($LASTEXITCODE -ne 0) { throw "报表导出失败：$($item.report_file)" }
  }
  Remove-Item -LiteralPath $driver -Force
  Write-Host "结算复核文件已生成：$output"
} catch {
  Remove-DerivedOutput
  Write-Error $_
  exit 2
}
