DROP SCHEMA IF EXISTS raw CASCADE;
DROP SCHEMA IF EXISTS settlement CASCADE;
CREATE SCHEMA raw;

CREATE TABLE raw.raw_tenant_account (
  tenant_id text PRIMARY KEY,
  tenant_name text NOT NULL,
  tenant_status text NOT NULL,
  settlement_currency text NOT NULL
);

CREATE TABLE raw.raw_merchant_profile (
  tenant_id text NOT NULL,
  merchant_id text NOT NULL,
  merchant_name text NOT NULL,
  merchant_status text NOT NULL,
  payout_account_id text NOT NULL,
  PRIMARY KEY (tenant_id, merchant_id)
);

CREATE TABLE raw.raw_settlement_ledger (
  voucher_id text PRIMARY KEY,
  tenant_id text NOT NULL,
  merchant_id text NOT NULL,
  original_voucher_id text,
  entry_type text NOT NULL,
  entry_status text NOT NULL,
  currency text NOT NULL,
  gross_cents integer NOT NULL,
  fee_cents integer NOT NULL,
  net_cents integer NOT NULL,
  occurred_at_utc timestamptz NOT NULL,
  source_event_id text NOT NULL
);
