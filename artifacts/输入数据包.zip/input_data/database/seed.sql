INSERT INTO raw.raw_tenant_account VALUES
('TNA','North app store','active','USD'),
('TNB','Euro creator shop','active','EUR'),
('TNC','Paused trial tenant','suspended','USD');

INSERT INTO raw.raw_merchant_profile VALUES
('TNA','M100','Active Threads','active','pa_live_100'),
('TNA','M101','ClipSmith','active','pa_live_101'),
('TNA','M102','Old Outlet','inactive','pa_old_102'),
('TNB','M200','Carton Club','active','pa_live_200'),
('TNB','M201','Market Lens','active','pa_live_201'),
('TNB','M202','Dormant Media','disabled','pa_disabled_202'),
('TNC','M300','Trial Coffee','active','pa_trial_300');

INSERT INTO raw.raw_settlement_ledger VALUES
('V-A-001','TNA','M100',NULL,'sale','posted','USD',12000,360,11640,'2026-07-03T04:11:00Z','pay_evt_1001'),
('V-A-002','TNA','M100',NULL,'sale','posted','USD',12800,384,12416,'2026-07-04T09:35:00Z','pay_evt_1002'),
('V-A-003','TNA','M101',NULL,'sale','posted','USD',9500,285,9215,'2026-07-05T14:22:00Z','pay_evt_1003'),
('V-A-004','TNA','M100',NULL,'refund','posted','USD',-4500,0,-4500,'2026-07-06T05:20:00Z','refund_evt_1004'),
('V-A-005','TNA','M102',NULL,'sale','posted','USD',7000,210,6790,'2026-07-06T11:08:00Z','pay_evt_1005'),
('V-A-006','TNA','M100',NULL,'sale','draft','USD',3000,90,2910,'2026-07-07T07:10:00Z','pay_evt_1006'),
('V-A-007','TNA','M101',NULL,'fee_adjust','posted','USD',0,100,-100,'2026-07-08T16:45:00Z','fee_adj_1007'),
('V-A-008','TNA','M100','V-A-002','reversal','posted','USD',-12800,-384,-12416,'2026-07-09T03:25:00Z','rev_evt_1008'),
('V-A-009','TNA','M101','V-A-003','reversal','posted','USD',-9000,-270,-8730,'2026-07-09T09:10:00Z','rev_evt_1009'),
('V-A-010','TNA','M100','V-A-002','reversal','posted','USD',-12800,-384,-12416,'2026-07-10T10:15:00Z','rev_evt_1010'),
('V-B-001','TNB','M200',NULL,'sale','posted','EUR',22000,660,21340,'2026-07-03T08:05:00Z','pay_evt_2001'),
('V-B-002','TNB','M201',NULL,'sale','posted','EUR',18000,540,17460,'2026-07-04T13:40:00Z','pay_evt_2002'),
('V-B-003','TNB','M200',NULL,'refund','posted','EUR',-6000,0,-6000,'2026-07-06T16:05:00Z','refund_evt_2003'),
('V-B-004','TNB','M200',NULL,'sale','posted','EUR',8100,243,7857,'2026-06-30T23:20:00Z','pay_evt_2004'),
('V-B-005','TNB','M201','V-B-002','reversal','posted','EUR',-18000,-540,-17460,'2026-07-08T07:30:00Z','rev_evt_2005'),
('V-B-006','TNB','M200','V-A-001','reversal','posted','EUR',-12000,-360,-11640,'2026-07-09T11:35:00Z','rev_evt_2006'),
('V-B-007','TNB','M200','V-B-005','reversal','posted','EUR',18000,540,17460,'2026-07-10T12:05:00Z','rev_evt_2007'),
('V-B-008','TNB','M202',NULL,'sale','posted','EUR',4000,120,3880,'2026-07-11T15:18:00Z','pay_evt_2008'),
('V-C-001','TNC','M300',NULL,'sale','posted','USD',5000,150,4850,'2026-07-05T10:00:00Z','pay_evt_3001');
